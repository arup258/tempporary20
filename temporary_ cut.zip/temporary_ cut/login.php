<?php 
include('./dbcon.php');
	session_start();
?>

<!DOCTYPE html>
<html lang="en">
<?php include('common/head.php'); ?>
    <body>
        <!-- Navigation-->
        <?php include('common/navbar.php'); ?>
        <!-- Page Header-->
        <header class="masthead" style="background-image: url('assets/img/home-bg.jpg')">
            <div class="container position-relative px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <div class="site-heading">
                            <h1>Login </h1>
                            <span class="subheading">A Blog Theme by Start Bootstrap</span>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- Main Content-->
        <html>  
<head>  
    <title>PHP login system</title>   
    <link rel = "stylesheet" type = "text/css" href = "style.css">   
</head>  
<body>  
    <div id = "frm"> 
        
    
        <a class="nav-link" href="post.php"></a>
      </li>    
        <div class="container mt-5">
    <h1>Login User</h1>
        <form action="" method="post">
        <?php
include('dbcon.php');
if (isset($_POST['login'])){

		$email=$_POST['email'];		
		$password=$_POST['password'];
        $query="SELECT * FROM user1 where email='$email' and password='$password' and isadmin='admin' ";
		$sql=mysqli_query($conn,$query);
		$row=mysqli_fetch_array($sql);
		if (is_array($row)) {
			
			$_SESSION["id"]=$row['id'];
			$_SESSION["name"]=$row['name'];
            //print_r($_SESSION); exit();
			//echo $_SESSION["id"]; exit();
			header('location:show.php');
        echo "<script> alert('login successful')</script>";
    }
		else{
		echo "<script> alert('login failed')</script>";
        
		}
    }
	
  ?>
        <div class="form-group">
            <label for="exampleInputEmail1">Email</label>
            <input type="email" class="form-control" id="exampleInputEmail1" name="email">
        </div>
        
        <div class="form-group">
            <label for="exampleInputEmail1">Password</label>
            <input type="password" class="form-control" id="exampleInputEmail1" name="password">
        </div>

        <div class="container mt-3">
        
     <button type="submit" class="btn btn-primary" name="login"> login</button>
</div>
        </form>
</div>
</div>

</div> 
</body>     
</html>
        <!-- Footer-->
        <?php include('common/footer.php'); 
        
        ?>
