<!DOCTYPE html>
    <html lang="en">
    <?php include('common/head.php'); ?>
        <body>
            <!-- Navigation-->
            <?php include('common/navbar.php'); ?>
            <!-- Page Header-->
            <header class="masthead" style="background-image: url('assets/img/post-bg.jpg')">
                <div class="container position-relative px-4 px-lg-5">
                    <div class="row gx-4 gx-lg-5 justify-content-center">
                        <div class="col-md-10 col-lg-8 col-xl-7">
                            <div class="post-heading">
                                <h1>Man must explore, and this is exploration at its greatest</h1>
                                <h2 class="subheading">Problems look mighty small from 150 miles up</h2>
                                <span class="meta">
                                    
                                    <a href="#!">
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            
    <table class="table mt-2">
  <thead>
    
  <h1> The Social Dilemma</h1>
      
             
<table>
The film dives into the psychological underpinnings and the manipulation techniques by which, it claims, social media and technology companies addict users. People's online activity is watched, tracked, and measured by these companies, who then use this data to build artificial intelligence models that predict the actions of their users. Tristan Harris, former Google design ethicist and co-founder of the Center for Humane Technology, explains in the documentary that there are three main goals of tech companies:

The engagement goal: to increase usage and to make sure users continue scrolling.
The growth goal: to ensure users are coming back and inviting friends that invite even more friends.
The advertisement goal: to make sure that while the above two goals are happening, the companies are also making as much money as possible from advertisements.
Social media and comments sections were created as a way for people to connect and have an online community. It’s ideal for long-distance friendships, locating and reconnecting with old friends from the past, and finding new people to connect with; it's been a literal necessity in the Covid era. Plus, in today’s modern world of online marketing and social media managing, many businesses also use it for digital advertising as it’s a cheaper option than print marketing. In theory, social media should give its users a sense of community and a place where they can safely express themselves through posts, pictures, videos, and other content.



    </tr>
  </thead>
</div>
    
  </tbody>
</table>

                  
<!-- Footer-->
<?php include('common/footer.php'); ?>


</body>
</html>