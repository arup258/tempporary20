<?php 
//$conn=mysqli_connect("host_name","user_name","password","dbname");

$conn=mysqli_connect("localhost","root","","student");
// if ($conn) {
//     echo "db connected successfully";
// }else{
//     echo "db not connected";
// }
?>