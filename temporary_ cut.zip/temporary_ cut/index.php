

<!DOCTYPE html>
<html lang="en">
<?php include('common/head.php'); ?>
    <body>
            
        <!-- Navigation-->
        <?php include('common/navbar.php'); ?>
        <!-- Page Header-->
        <header class="masthead" style="background-image: url('assets/img/home-bg.jpg')">
            <div class="container position-relative px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <div class="site-heading">
                            <h1>Clean Blog</h1>
                            <span class="subheading">A Blog Theme by Start Bootstrap</span>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- Main Content-->
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-md-10 col-lg-8 col-xl-7">
                    <!-- Post preview-->
                    <div class="post-preview">
                        <a href="login.php">

                            <h2 class="post-title">The Social Dilemma</h2>
                            <h3 class="post-subtitle">the mental health of adolescents and rising teen suicide rates.</h3>
                        </a>
                        <p class="post-meta">
                            Posted by
                            <a href="#!">
                        </p>
                    </div>
                    <!-- Divider-->
                    <hr class="my-4" />
                    <!-- Post preview-->
                    <div class="post-preview">
                        <a href="show.php"><h2 class="post-title">I believe every human has a finite number of heartbeats. I don't intend to waste any of mine.</h2></a>
                        <p class="post-meta">
                            Posted by
                            <a href="#!">
                        </p>
                    </div>
                    <!-- Divider-->
                    <hr class="my-4" />
                    <!-- Post preview-->
                    <div class="post-preview">
                        <a href="show.php">
                            <h2 class="post-title">Science has not yet mastered prophecy</h2>
                            <h3 class="post-subtitle">We predict too much for the next year and yet far too little for the next ten.</h3>
                        </a>
                        <p class="post-meta">
                            Posted by
                            <a href="#!">
                        </p>
                    </div>
                    <!-- Divider-->
                    <hr class="my-4" />
                    <!-- Post preview-->
                    <div class="post-preview">
                        <a href="show.php">
                            <h2 class="post-title">Failure is not an option</h2>
                            <h3 class="post-subtitle">Many say exploration is part of our destiny, but it’s actually our duty to future generations.</h3>
                        </a>
                        <p class="post-meta">
                            Posted by
                            <a href="#!">
                        </p>
                    </div>
                    <!-- Divider-->
                    <hr class="my-4" />
                    <!-- Pager-->
                    <div class="d-flex justify-content-end mb-4"><a class="btn btn-primary text-uppercase" href="#!">Older Posts →</a></div>

                    <!-- <div class="container mt-5"> -->
 
 <table class="table mt-2">
<thead>
 <tr>
   <th scope="col">Id</th>
   <th scope="col">title</th>
   <th scope="col">sub_title</th>
   <th scope="col">content</th>
   
   <?php 
 include('./dbcon.php');
 $query="select * from user2";
 $sql=mysqli_query($conn,$query);
 ?>
 <?php while($row=mysqli_fetch_assoc($sql)) { ?>
 <tr>
   <th scope="row"><?php echo $row['id']?></th>
   <td class=><?php echo $row['title']?></td>
   <td class=><?php echo $row['sub_title']?></td>
   <td class=><?php echo $row['content']?></td>

 <?php } ?>

 </div>





                    
                </div>
            </div>
        </div>

        


    
        
        

        <!-- Footer
        <?php //include('common/footer.php'); ?> -->

    </body>
    </html>