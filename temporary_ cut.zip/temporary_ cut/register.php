<?php 
    include('./dbcon.php');
	session_start();

  //  if (isset($_SESSION['id'])) {
  //    header('location:student.php');
  // }
?>

<!DOCTYPE html>
<html lang="en">
<?php include('common/head.php'); ?>
    <body>  

        <!-- Navigation-->
        <?php include('common/navbar.php'); ?>
        <!-- Page Header-->
        <header class="masthead" style="background-image: url('assets/img/home-bg.jpg')">
            <div class="container position-relative px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <div class="site-heading">
                            <h1>Register </h1>
                            <span class="subheading">A Blog Theme by Start Bootstrap</span>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- Main Content-->
        <html>  
<head>  
    <title>PHP Register system</title>   
    <link rel = "stylesheet" type = "text/css" href = "style.css">   
</head>  
<body>  
    
<div class="container mt-5">
<h1>Register User</h1>
    <form action="" method="post">
    <div class="form-group">
      <label for="usr">Name:</label>
      <input type="text" class="form-control" id="usr" name="name">
    </div>
    <div class="form-group">
      <label for="usr">Email:</label>
      <input type="email" class="form-control" id="usr" name="email">
    </div>
    <div class="form-group">
      <label for="usr">Phone No:</label>
      <input type="text" class="form-control" id="usr" name="phone">
    </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="pwd" name="password">
    </div>
    <div class="form-group">
      <label for="pwd">Confirm Password:</label>
      <input type="password" class="form-control" id="pwd" name="c_password">
    </div>
      <div class="form-group">
            <label for="exampleInputEmail1">Image</label>
            <input type="file" class="form-control" id="exampleInputEmail1" name="image">
        </div>
     <input type="submit" name="signup" value="Sign Up" class="btn btn-primary">
</div>


 
  <?php
  include('./dbcon.php');
  if (isset($_POST['signup'])) {
    if($_POST['password']==$_POST['c_password']){
      $name=$_POST['name'];
      $email=$_POST['email'];
      $phone=$_POST['phone'];
      $password=$_POST['password'];
      $file_name=$_FILES['image']['name'];
	//print_r($file_name); exit();
    $file_type=$_FILES['image']['type'];
	$file_size=$_FILES['image']['size'];
	$file_temp_loc=$_FILES['image']['tmp_name'];
	$file_store="upload/".$file_name;
	move_uploaded_file($file_temp_loc, $file_store);


      $query="insert into user1  (name, email, phone, password,image) values('$name', '$email', '$phone', '$password','$image')";
      $sql=mysqli_query($conn,$query);
      
      if ($sql) {
        echo "<script>window.location.href='http://localhost/temporary_%20cut/login.php'</script>";;
      }
      else{
        echo "<script> alert('failed')</script>";
      }
    }
    
  }


  ?>


            

  </div> 
  </body>     
  </html>
        <!-- Footer-->
        <?php include('common/footer.php'); 
          
        ?>
